package com.app.inventory.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class RegistroController {
	
	@GetMapping("/login")
	public String login() {
	 return "login";
	}
	
	/*@GetMapping("/registro")
	public String registro() {
	 return "registro";
	}*/
	
	@GetMapping("/")
	public String VerPagina() {
	 return "index";
	}
	
	@GetMapping("/index-particles")
	public String VerPagina2() {
	 return "index-particles";
	}
	
	@GetMapping("/ups")
	public String VerError() {
	 return "ups";
	}
	
}
