package com.app.inventory.facade;

import java.util.List;

import com.app.inventory.model.Rol;

public interface IRole {

	public List<Rol>Encontrarrole();
}
